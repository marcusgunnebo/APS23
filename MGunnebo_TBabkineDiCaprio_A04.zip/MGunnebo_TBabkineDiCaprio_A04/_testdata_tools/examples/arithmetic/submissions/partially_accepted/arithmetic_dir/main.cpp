#include <bits/stdc++.h>
// A submission in a directory
// @EXPECTED_GRADES@ AC AC WA WA
using namespace std;

int main() {
	double a, b, c;
	cin >> a >> b >> c;
	cout << setprecision(18) << fixed << a * b / c << endl;
}
