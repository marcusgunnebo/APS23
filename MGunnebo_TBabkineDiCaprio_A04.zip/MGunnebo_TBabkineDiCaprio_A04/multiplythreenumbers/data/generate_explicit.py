#! /usr/env/python3
import sys

x, y, z = map(int, sys.argv[1:-1])
print (x,y,z)