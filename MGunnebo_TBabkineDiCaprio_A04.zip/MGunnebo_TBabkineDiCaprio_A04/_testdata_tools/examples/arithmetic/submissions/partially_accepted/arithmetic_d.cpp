#include <bits/stdc++.h>
using namespace std;

int main() {
	double a, b, c;
	cin >> a >> b >> c;
	cout << setprecision(18) << fixed << a * b / c << endl;
}
