#!/usr/bin/env python3
# @EXPECTED_GRADES@ RTE RTE RTE RTE

assert False
