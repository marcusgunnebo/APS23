#!/usr/bin/env bash

# Prints the input, then the random seed (for use by the interactive validator)
echo "$@"
