This directory contains example problems that use testdata_tools:

* codforces: from PO finals 2019 (kodkraft), standard problem
* lampswitches: from PO finals 2019 (lampknappar), standard problem with more complex generators
* arithmetic: from BOI 2018, uses a custom validator, shows some features of analyzetestgroups.py
* nintetynine: from BOI 2018, interactive problem
